using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Newtonsoft.Json;
using UnityEngine.Networking;

public class MyWebRequest : MonoBehaviour
{
    private string m_hostAddress = "http://192.168.41.200:8080/";
    public class GameRecord
    { 
        public string Username;
        public uint Score;
    }

    // Start is called before the first frame update
    void Start()
    {

    }


    IEnumerator GetHighestRecord()
    {
        // set the request URL

        // using UnityWebRequest and Get for send web request

        // wait for response
        yield return 0;

        // check be successful

        // log the JSON string in result

        // JSON string to object
    }

    public void GetGameTop10Records()
    {
        // get the top 10 records
    }

    IEnumerator GetTop10Records()
    {
        // set the request URL

        // using UnityWebRequest and Get for send web request

        // wait for response
        yield return 0;

        // check be successful

        // log the JSON string in result

        // JSON string to object

        // update UI
    }

    public void UploadRecord(string name, int score)
    {
        // generate record object

        // object to JSON string

        // send upload request with JSON string
    }

    IEnumerator UploadRecord(string postData)
    {
        // set the request URL

        // using UnityWebRequest and Post for send web request

        // wait for response
        yield return 0;

        // log the JSON string in result

        // JSON string to object

        // update UI
    }
}
